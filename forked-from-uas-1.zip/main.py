'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import tkinter as tk 

from tkinter import messagebox 

  



rooms = { 

    'M': ('melati', 650000), 

    'S': ('Sakura', 550000), 

    'L': ('Lily', 400000), 

    'A': ('Anggrek', 350000), 

} 

  


def calculate_total(): 

    try: 

        days = int(entry_days.get()) 

        room_code = entry_room_code.get().upper() 

        amount_paid = int(entry_amount_paid.get()) 

        if room_code not in rooms: 

            messagebox.showerror("Error", "Kode kamar tidak valid") 

            return 

  

        room_name, price_per_night = rooms[room_code] 

  

       

        total_cost = days * price_per_night 

  

       

        if days > 5: 

            discount = 0.10 

        elif days > 3: 

            discount = 0.05 

        else: 

            discount = 0 

  

        total_cost_with_discount = total_cost * (1 - discount) 

  

        
        ppn = 0.1 * total_cost_with_discount 

  

       

        final_amount = total_cost_with_discount + ppn 

  

        

        change = amount_paid - final_amount 

  

        

        result_text = ( 

            f"Hotel 'SEJUK ASRI'\n" 

            f"===================\n" 

            f"Nama Petugas: {entry_petugas.get()}\n" 

            f"Nama Customer: {entry_customer.get()}\n" 

            f"Tanggal Check In: {entry_checkin.get()}\n" 

            f"Nama Kamar: {room_name}\n" 

            f"Lama Sewa: {days} hari\n" 

            f"Harga Sewa per Malam: Rp. {price_per_night:.2f}\n" 

            f"Diskon: {discount*100:.2f}%\n" 

            f"PPN: Rp. {ppn:.2f}\n" 

            f"Total Bayar: Rp. {final_amount:.2f}\n" 

            f"Uang Bayar: Rp. {amount_paid:.2f}\n" 

            f"Uang Kembali: Rp. {change:.2f}\n" 

        ) 

        label_result.config(text=result_text) 

    except ValueError: 

        messagebox.showerror("Error", "Masukkan jumlah hari dan jumlah uang bayar yang valid") 

  



def clear_all(): 

    entry_petugas.delete(0, tk.END) 

    entry_customer.delete(0, tk.END) 

    entry_checkin.delete(0, tk.END) 

    entry_room_code.delete(0, tk.END) 

    entry_days.delete(0, tk.END) 

    entry_amount_paid.delete(0, tk.END) 

    label_result.config(text="") 

  



def pause_program(): 

    messagebox.showinfo("Pause", "Program dihentikan sementara.") 

  



def update_mode(): 

    mode = mode_var.get() 

    if mode == "Check-in": 

        label_checkin.grid() 

        entry_checkin.grid() 

        label_days.grid() 

        entry_days.grid() 

        label_amount_paid.grid() 

        entry_amount_paid.grid() 

        button_calculate.config(text="Hitung Pembayaran") 

    elif mode == "Check-out": 

        label_checkin.grid_remove() 

        entry_checkin.grid_remove() 

        label_days.grid_remove() 

        entry_days.grid_remove() 

        label_amount_paid.grid_remove() 

        entry_amount_paid.grid_remove() 

        button_calculate.config(text="Hitung Kembalian") 

  



root = tk.Tk() 

root.title("Hotel Sejuk Asri - Pembayaran") 

root.configure(bg="#1a237e") 

  



tk.Label(root, text="Hotel Sejuk Asri", bg="#1a237e", fg="#ffffff", font=("Helvetica", 16, "bold")).grid(row=0, column=0, columnspan=2, pady=10) 

  

tk.Label(root, text="Mode:", bg="#1a237e", fg="#ffffff").grid(row=1, column=0, sticky="w", padx=10, pady=5) 

mode_var = tk.StringVar(value="Check-in") 

tk.Radiobutton(root, text="Check-in", variable=mode_var, value="Check-in", bg="#1a237e", fg="#ffffff", command=update_mode).grid(row=1, column=1, sticky="w") 

tk.Radiobutton(root, text="Check-out", variable=mode_var, value="Check-out", bg="#1a237e", fg="#ffffff", command=update_mode).grid(row=1, column=1, sticky="e") 

  

tk.Label(root, text="Nama Petugas:", bg="#1a237e", fg="#ffffff").grid(row=2, column=0, sticky="w", padx=10, pady=5) 

entry_petugas = tk.Entry(root, bg="#ffffff", fg="#1a237e") 

entry_petugas.grid(row=2, column=1, padx=10, pady=5) 

  

tk.Label(root, text="Nama Customer:", bg="#1a237e", fg="#ffffff").grid(row=3, column=0, sticky="w", padx=10, pady=5) 

entry_customer = tk.Entry(root, bg="#ffffff", fg="#1a237e") 

entry_customer.grid(row=3, column=1, padx=10, pady=5) 

  

label_checkin = tk.Label(root, text="Tanggal Check-in (DD-MM-YYYY):", bg="#1a237e", fg="#ffffff") 

label_checkin.grid(row=4, column=0, sticky="w", padx=10, pady=5) 

entry_checkin = tk.Entry(root, bg="#ffffff", fg="#1a237e") 

entry_checkin.grid(row=4, column=1, padx=10, pady=5) 

  

tk.Label(root, text="Kode Kamar:", bg="#1a237e", fg="#ffffff").grid(row=5, column=0, sticky="w", padx=10, pady=5) 

entry_room_code = tk.Entry(root, bg="#ffffff", fg="#1a237e") 

entry_room_code.grid(row=5, column=1, padx=10, pady=5) 

  

label_days = tk.Label(root, text="Lama Sewa (hari):", bg="#1a237e", fg="#ffffff") 

label_days.grid(row=6, column=0, sticky="w", padx=10, pady=5) 

entry_days = tk.Entry(root, bg="#ffffff", fg="#1a237e") 

entry_days.grid(row=6, column=1, padx=10, pady=5) 

  

label_amount_paid = tk.Label(root, text="Uang Bayar:", bg="#1a237e", fg="#ffffff") 

label_amount_paid.grid(row=7, column=0, sticky="w", padx=10, pady=5) 

entry_amount_paid = tk.Entry(root, bg="#ffffff", fg="#1a237e") 

entry_amount_paid.grid(row=7, column=1, padx=10, pady=5) 

  

button_calculate = tk.Button(root, text="Hitung Pembayaran", command=calculate_total, bg="#3949ab", fg="#ffffff") 

button_calculate.grid(row=8, column=0, columnspan=2, padx=10, pady=10) 

  

label_result = tk.Label(root, text="", justify=tk.LEFT, bg="#1a237e", fg="#ffffff", font=("Helvetica", 10, "bold")) 

label_result.grid(row=9, column=0, columnspan=2, padx=10, pady=10) 

  

tk.Button(root, text="Clear", command=clear_all, bg="#d32f2f", fg="#ffffff").grid(row=10, column=0, padx=10, pady=10) 

tk.Button(root, text="Pause", command=pause_program, bg="#1976d2", fg="#ffffff").grid(row=10, column=1, padx=10, pady=10) 

  

 

root.mainloop() 