'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def luas_segiempat(sisi):
    return sisi ** 2

def keliling_segiempat(sisi):
    return 4 * sisi

def luas_persegipanjang(panjang, lebar):
    return panjang * lebar

def keliling_persegipanjang(panjang, lebar):
    return 2 * (panjang + lebar)

def luas_segitiga(alas, tinggi):
    return 0.5 * alas * tinggi

def keliling_segitiga(sisi_a, sisi_b, sisi_c):
    return sisi_a + sisi_b + sisi_c

def luas_lingkaran(jari_jari):
    return 3.14 * jari_jari ** 2

def keliling_lingkaran(jari_jari):
    return 2 * 3.14 * jari_jari

def menu():
    print("Pilih bangun datar yang ingin dihitung:")
    print("1. Segi Empat")
    print("2. Persegi Panjang")
    print("3. Segitiga")
    print("4. Lingkaran")
    print("0. Keluar")

def hitung_bangun_datar():
    while True:
        menu()
        pilihan = input("Masukkan pilihan Anda (0-4): ")
        
        if pilihan == '1':
            sisi = float(input("Masukkan panjang sisi: "))
            print(f"Luas Segi Empat: {luas_segiempat(sisi)}")
            print(f"Keliling Segi Empat: {keliling_segiempat(sisi)}")
        elif pilihan == '2':
            panjang = float(input("Masukkan panjang: "))
            lebar = float(input("Masukkan lebar: "))
            print(f"Luas Persegi Panjang: {luas_persegipanjang(panjang, lebar)}")
            print(f"Keliling Persegi Panjang: {keliling_persegipanjang(panjang, lebar)}")
        elif pilihan == '3':
            alas = float(input("Masukkan panjang alas: "))
            tinggi = float(input("Masukkan tinggi: "))
            sisi_a = float(input("Masukkan panjang sisi A: "))
            sisi_b = float(input("Masukkan panjang sisi B: "))
            sisi_c = float(input("Masukkan panjang sisi C: "))
            print(f"Luas Segitiga: {luas_segitiga(alas, tinggi)}")
            print(f"Keliling Segitiga: {keliling_segitiga(sisi_a, sisi_b, sisi_c)}")
        elif pilihan == '4':
            jari_jari = float(input("Masukkan panjang jari-jari: "))
            print(f"Luas Lingkaran: {luas_lingkaran(jari_jari)}")
            print(f"Keliling Lingkaran: {keliling_lingkaran(jari_jari)}")
        elif pilihan == '0':
            print("Terima kasih telah menggunakan program ini.")
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

if __name__ == "__main__":
    hitung_bangun_datar()
