'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# Definisikan kelas untuk barang
class Barang:
    def __init__(self, nama, harga, stok):
        self.nama = nama
        self.harga = harga
        self.stok = stok

    def __str__(self):
        return f"Nama: {self.nama}, Harga: Rp. {self.harga}, Stok: {self.stok}"

# Daftar barang
barang_list = []

# Fungsi untuk menambah data barang
def tambah_barang():
    nama = input("Masukkan Nama Barang: ")
    harga = int(input("Masukkan Harga Barang: "))
    stok = int(input("Masukkan Stok Barang: "))
    barang = Barang(nama, harga, stok)
    barang_list.append(barang)
    print("Barang berhasil ditambahkan!\n")

# Fungsi untuk menampilkan data barang
def tampilkan_barang():
    if not barang_list:
        print("Tidak ada data barang.\n")
        return
    for idx, barang in enumerate(barang_list, 1):
        print(f"{idx}. {barang}")
    print()

# Fungsi untuk menghapus data barang
def hapus_barang():
    tampilkan_barang()
    if not barang_list:
        return
    idx = int(input("Masukkan nomor barang yang akan dihapus: ")) - 1
    if 0 <= idx < len(barang_list):
        del barang_list[idx]
        print("Barang berhasil dihapus!\n")
    else:
        print("Nomor barang tidak valid.\n")

# Fungsi untuk mencari data barang
def cari_barang():
    keyword = input("Masukkan nama barang yang dicari: ").lower()
    ditemukan = False
    for barang in barang_list:
        if keyword in barang.nama.lower():
            print(barang)
            ditemukan = True
    if not ditemukan:
        print("Barang tidak ditemukan.\n")

# Fungsi untuk melakukan transaksi pembelian
def beli_barang():
    tampilkan_barang()
    if not barang_list:
        return
    idx = int(input("Masukkan nomor barang yang ingin dibeli: ")) - 1
    if 0 <= idx < len(barang_list):
        barang = barang_list[idx]
        jumlah = int(input("Masukkan jumlah yang ingin dibeli: "))
        if jumlah > barang.stok:
            print("Stok tidak mencukupi.\n")
        else:
            total_harga = jumlah * barang.harga
            barang.stok -= jumlah
            print(f"Total harga yang harus dibayar: Rp. {total_harga}")
            print("Transaksi berhasil!\n")
    else:
        print("Nomor barang tidak valid.\n")

# Fungsi utama untuk menampilkan menu
def menu():
    while True:
        print("Menu:")
        print("1. Input Data Barang")
        print("2. Tampilkan Data Barang")
        print("3. Hapus Data Barang")
        print("4. Cari Data Barang")
        print("5. Beli Barang")
        print("0. Keluar")
        pilihan = input("Pilih menu (0-5): ")

        if pilihan == '1':
            tambah_barang()
        elif pilihan == '2':
            tampilkan_barang()
        elif pilihan == '3':
            hapus_barang()
        elif pilihan == '4':
            cari_barang()
        elif pilihan == '5':
            beli_barang()
        elif pilihan == '0':
            print("Terima kasih telah menggunakan program ini.")
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.\n")

if __name__ == "__main__":
    menu()
